---
name: Help Wanted
about: Ask for help about using Maverick.
title: ''
labels: 'help wanted'
assignees: ''
---


**Problem description**


**Environment and configuration**

* Python Version: 
* pip Version: 

<!-- Please copy and paste your config.py here, or upload it as an attachment. -->


**Additional information**
