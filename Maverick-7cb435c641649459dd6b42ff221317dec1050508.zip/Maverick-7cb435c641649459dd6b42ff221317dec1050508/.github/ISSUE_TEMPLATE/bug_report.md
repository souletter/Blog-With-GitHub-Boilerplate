---
name: Bug Report
about: Report a bug to author.
title: ''
labels: 'bug'
assignees: ''
---


**Actual behavior**


**Expected behavior**


**How to reproduce**


**Environment and configuration**

* Python Version: 
* pip Version: 

<!-- Please copy and paste your config.py here, or upload it as an attachment. -->


**Error log**
<!-- Copy error log from your terminal and paste it here. -->


**Additional information**
