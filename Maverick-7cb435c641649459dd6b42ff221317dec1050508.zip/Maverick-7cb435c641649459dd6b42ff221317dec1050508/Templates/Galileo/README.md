# Galileo

Default theme for [Maverick](https://github.com/AlanDecode/Maverick).

© [AlanDecode](https://github.com/AlanDecode)
