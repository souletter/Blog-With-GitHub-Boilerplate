# -*- coding: utf-8 -*-
"""Maverick: Go My Own Way

Author: AlanDecode | 熊猫小A
Link:   https://www.imalan.cn
GitHub: https://github.com/AlanDecode
"""
